class ConversationData:
    def __init__(
        self,
        did_welcome: bool = False
    ):
        self.did_welcome = did_welcome